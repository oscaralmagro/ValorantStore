# Tienda Valorant

App Android (no oficial) para ver tu tienda diaria de Valorant. No está afiliada ni respaldada por Riot Games.

- Inicias sesión en la página oficial de Riot dentro de la app. La app nunca ve tu contraseña.
- El token se guarda cifrado en tu móvil y las peticiones van directas del móvil a Riot.
- Usa la API interna del cliente (no documentada): puede dejar de funcionar con un parche y su uso es bajo tu responsabilidad.

## Apoya al creador
- PayPal: https://paypal.me/Oscarlmgr
- YouTube: https://www.youtube.com/@crosswt7
- Twitch: https://www.twitch.tv/oscaralmagroo

## Compilar
Sube el proyecto a GitHub, ve a Actions > Build APK > Run workflow. El APK aparece en Artifacts. Con una etiqueta `v1.0.0` se publica en Releases.
